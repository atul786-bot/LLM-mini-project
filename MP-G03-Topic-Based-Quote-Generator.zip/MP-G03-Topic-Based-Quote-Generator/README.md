# MP-G03 – Topic-Based Quote Generator

LLM Mini Project, Large Language Models (ISE23704C), VII Sem ISE, Global Academy of Technology.
Student: Atul Kumar J H A (1GA23IS026), Section 7A.

A GPT-2 small (124M) model, built with the course `GPTModel` code and initialised with the pretrained GPT-2 weights, is continued-pretrained on topic-tagged quotes written as `Topic: <topic>\nQuote: <quote>`. The app `quote_of_the_day(topic)` generates a new quote for a chosen topic.

## Files
- `MP_G03_Custom_GPT_Quote_Generator.ipynb`: the complete notebook (data, model, training, evaluation, app)
- `requirements.txt`: Python packages
- `data/quotes_clean.zip`: the dataset (`quotes_clean.csv`, columns quote, author, topic; 171,492 records, 8 topics), zipped to stay under GitHub's upload limit. It is derived from Quotes-500K: S. Goel, R. Madhok and S. Garg, "Proposing contextually relevant quotes for images," ECIR 2018. It is shared here only for academic coursework.

## How to run (Google Colab)
1. Open the notebook in Colab and choose Runtime → Change runtime type → T4 GPU.
2. Download `data/quotes_clean.zip` from this repository and unzip it to get `quotes_clean.csv`.
3. Run the cells from top to bottom. When the upload dialog appears, upload `quotes_clean.csv`.
4. The training cell runs 150 batches (about 0.3 min on a T4) and prints the validation loss and perplexity before and after training.
5. The checkpoint cell saves `custom_gpt_quote_checkpoint.pt` and reloads it. The Gradio cell then serves the reloaded model through a public link.

## Results (seed 42)
| Metric (first 30 validation batches) | Before | After |
|---|---|---|
| Validation loss | 4.4409 | 3.3582 |
| Perplexity | 84.85 | 28.74 |

Exact-match novelty of the 9 generated quotes against the training split: 100%.

Model weight files (`.pt`) are not included in this repository.
